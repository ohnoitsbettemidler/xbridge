#!/bin/bash
# Builds the host-side test rig: the real Pi-link add-on compiled against fake
# hardware, so the Pi tests can push packets through the firmware code.
# Needs g++ and a GP2040-CE checkout with the XBridge patch applied:
#   GP2040=/path/to/GP2040-CE bash build.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
GP2040="${GP2040:?set GP2040 to your patched GP2040-CE folder}"
g++ -std=c++17 -O1 -include "$HERE/stubs/pico_compat.h" \
    -include "$GP2040/configs/XBridgeFeather/BoardConfig.h" \
    -I"$HERE/stubs" -I"$GP2040/headers" \
    -o "$HERE/harness" "$HERE/harness.cpp" "$GP2040/src/addons/pilink.cpp"
echo "Built $HERE/harness - now run: cd ../../pi && python3 -m unittest discover -s tests"
