// Host-side harness: runs the real firmware add-on (src/addons/pilink.cpp)
// against fake hardware. Commands come on stdin, results go to stdout as JSON.
#include <cstdio>
#include <cstring>
#include <deque>
#include <iostream>
#include <sstream>
#include <string>
#include <climits>

#include "storagemanager.h"
#include "drivermanager.h"
#include "drivers/xbone/XBOneDriver.h"
#include "hardware/i2c.h"
#include "pico/i2c_slave.h"
#include "addons/pilink.h"

i2c_inst_t g_i2c1 = {1};
std::deque<uint8_t> g_rxfifo, g_txout;
i2c_slave_handler_t g_handler = nullptr;
uint8_t g_addr = 0;
uint64_t g_now_us = 0;
bool g_mounted = false, g_auth_done = false;
int g_led = -1, g_5v = -1;

static std::deque<uint8_t> hexbytes(const std::string& hex) {
    std::deque<uint8_t> out;
    for (size_t i = 0; i + 1 < hex.size(); i += 2) out.push_back((uint8_t)std::stoi(hex.substr(i, 2), nullptr, 16));
    return out;
}

int main() {
    PiLinkInput addon;
    XBOneDriver xbone;
    DriverManager::getInstance().driver = &xbone;
    std::string line;
    while (std::getline(std::cin, line)) {
        std::istringstream ss(line);
        std::string cmd; ss >> cmd;
        if (cmd == "time") { uint64_t us; ss >> us; g_now_us = us; }
        else if (cmd == "setup") {
            addon.setup();
            printf("{\"addr\":%d,\"analog_triggers\":%d,\"led\":%d,\"usb5v\":%d,\"active\":%d}\n", g_addr,
                   Storage::getInstance().GetGamepad()->hasAnalogTriggers ? 1 : 0, g_led, g_5v, PiLinkInput::isActive() ? 1 : 0);
        }
        else if (cmd == "write" || cmd == "writelate") {
            std::string hex; ss >> hex;
            auto bytes = hexbytes(hex);
            if (cmd == "write") {          // normal: interrupt per byte, then stop
                for (auto b : bytes) { g_rxfifo.push_back(b); g_handler(&g_i2c1, I2C_SLAVE_RECEIVE); }
                g_handler(&g_i2c1, I2C_SLAVE_FINISH);
            } else {                        // late interrupt: stop seen before bytes were read (SDK order)
                for (auto b : bytes) g_rxfifo.push_back(b);
                g_handler(&g_i2c1, I2C_SLAVE_FINISH);
                g_handler(&g_i2c1, I2C_SLAVE_RECEIVE);
            }
        }
        else if (cmd == "read") {
            int n; ss >> n; g_txout.clear();
            for (int i = 0; i < n; i++) g_handler(&g_i2c1, I2C_SLAVE_REQUEST);
            g_handler(&g_i2c1, I2C_SLAVE_FINISH);
            printf("{\"read\":[");
            for (size_t i = 0; i < g_txout.size(); i++) printf("%s%d", i ? "," : "", g_txout[i]);
            printf("]}\n");
        }
        else if (cmd == "mounted") { int v; ss >> v; g_mounted = v; }
        else if (cmd == "auth") { int v; ss >> v; g_auth_done = v; }
        else if (cmd == "pre") {
            Gamepad* g = Storage::getInstance().GetGamepad();
            addon.preprocess();
            // Same conversion XBOneDriver::process() applies to build the Xbox report
            int16_t xLX = static_cast<int16_t>(g->state.lx) + INT16_MIN;
            int16_t xLY = static_cast<int16_t>(~g->state.ly) + INT16_MIN;
            int16_t xRX = static_cast<int16_t>(g->state.rx) + INT16_MIN;
            int16_t xRY = static_cast<int16_t>(~g->state.ry) + INT16_MIN;
            uint16_t xLT = g->hasAnalogTriggers ? ((g->state.lt << 2) | (g->state.lt >> 6)) : 0;
            uint16_t xRT = g->hasAnalogTriggers ? ((g->state.rt << 2) | (g->state.rt >> 6)) : 0;
            printf("{\"buttons\":%u,\"dpad\":%u,\"lx\":%u,\"ly\":%u,\"rx\":%u,\"ry\":%u,\"lt\":%u,\"rt\":%u,"
                   "\"xbox\":{\"lx\":%d,\"ly\":%d,\"rx\":%d,\"ry\":%d,\"lt\":%u,\"rt\":%u},\"led\":%d}\n",
                   g->state.buttons, g->state.dpad, g->state.lx, g->state.ly, g->state.rx, g->state.ry,
                   g->state.lt, g->state.rt, xLX, xLY, xRX, xRY, xLT, xRT, g_led);
        }
        fflush(stdout);
    }
    return 0;
}
