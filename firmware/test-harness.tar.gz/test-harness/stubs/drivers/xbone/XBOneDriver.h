#pragma once
#include "drivermanager.h"
extern bool g_auth_done;
class XBOneDriver : public GPDriver { public: bool getAuthSent() { return g_auth_done; } };
