#pragma once
#include <string>
#include "gamepad.h"
class GPAddon { public: virtual ~GPAddon() {} virtual bool available()=0; virtual void setup()=0; virtual void process()=0;
  virtual void preprocess()=0; virtual void postprocess(bool)=0; virtual std::string name()=0; virtual void reinit()=0; };
