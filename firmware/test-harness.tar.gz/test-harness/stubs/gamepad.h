#pragma once
#include <stdint.h>
#define GAMEPAD_MASK_UP    (1U << 0)
#define GAMEPAD_MASK_DOWN  (1U << 1)
#define GAMEPAD_MASK_LEFT  (1U << 2)
#define GAMEPAD_MASK_RIGHT (1U << 3)
#define GAMEPAD_MASK_B1    (1U << 0)
#define GAMEPAD_MASK_B2    (1U << 1)
#define GAMEPAD_MASK_B3    (1U << 2)
#define GAMEPAD_MASK_B4    (1U << 3)
#define GAMEPAD_MASK_L1    (1U << 4)
#define GAMEPAD_MASK_R1    (1U << 5)
#define GAMEPAD_MASK_L2    (1U << 6)
#define GAMEPAD_MASK_R2    (1U << 7)
#define GAMEPAD_MASK_S1    (1U << 8)
#define GAMEPAD_MASK_S2    (1U << 9)
#define GAMEPAD_MASK_L3    (1U << 10)
#define GAMEPAD_MASK_R3    (1U << 11)
#define GAMEPAD_MASK_A1    (1U << 12)
#define GAMEPAD_MASK_A2    (1U << 13)
#define GAMEPAD_JOYSTICK_MID 0x7FFF
struct GamepadState { uint8_t dpad{0}; uint32_t buttons{0}; uint16_t lx{GAMEPAD_JOYSTICK_MID}, ly{GAMEPAD_JOYSTICK_MID},
  rx{GAMEPAD_JOYSTICK_MID}, ry{GAMEPAD_JOYSTICK_MID}; uint8_t lt{0}, rt{0}; };
class Gamepad { public: GamepadState state; bool hasAnalogTriggers = false; };
