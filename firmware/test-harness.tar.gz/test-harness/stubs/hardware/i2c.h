#pragma once
#include <stdint.h>
#include <deque>
typedef struct i2c_inst { int id; } i2c_inst_t;
extern i2c_inst_t g_i2c1; extern std::deque<uint8_t> g_rxfifo; extern std::deque<uint8_t> g_txout;
#define i2c1 (&g_i2c1)
static inline unsigned i2c_init(i2c_inst_t*, unsigned b) { return b; }
static inline size_t i2c_get_read_available(i2c_inst_t*) { return g_rxfifo.size(); }
static inline uint8_t i2c_read_byte_raw(i2c_inst_t*) { uint8_t b = g_rxfifo.front(); g_rxfifo.pop_front(); return b; }
static inline void i2c_write_byte_raw(i2c_inst_t*, uint8_t b) { g_txout.push_back(b); }
