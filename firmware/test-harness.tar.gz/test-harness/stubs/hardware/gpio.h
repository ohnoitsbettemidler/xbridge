#pragma once
#include <stdint.h>
#define GPIO_FUNC_I2C 3
#define GPIO_OUT 1
extern int g_led, g_5v;
static inline void gpio_init(int) {} static inline void gpio_set_function(int, int) {} static inline void gpio_pull_up(int) {}
static inline void gpio_set_dir(int, int) {}
static inline void gpio_put(int pin, int v) { if (pin == 13) g_led = v; if (pin == 18) g_5v = v; }
