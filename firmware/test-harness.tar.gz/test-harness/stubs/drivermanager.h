#pragma once
#include "enums.pb.h"
class GPDriver { public: virtual ~GPDriver() {} };
class DriverManager { public: static DriverManager& getInstance() { static DriverManager d; return d; }
  InputMode getInputMode() { return mode; } GPDriver* getDriver() { return driver; } InputMode mode = INPUT_MODE_XBONE; GPDriver* driver = nullptr; };
