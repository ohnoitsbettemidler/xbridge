#pragma once
typedef enum { INPUT_MODE_XINPUT = 0, INPUT_MODE_XBONE = 11 } InputMode;
