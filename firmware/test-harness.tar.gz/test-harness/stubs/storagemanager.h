#pragma once
#include "gamepad.h"
class Storage { public: static Storage& getInstance() { static Storage s; return s; } Gamepad* GetGamepad() { return &pad; } Gamepad pad; };
