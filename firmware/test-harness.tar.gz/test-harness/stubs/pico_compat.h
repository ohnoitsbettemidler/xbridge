#define __not_in_flash_func(x) x
