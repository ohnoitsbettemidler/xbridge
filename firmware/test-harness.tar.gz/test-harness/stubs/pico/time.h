#pragma once
#include <stdint.h>
extern uint64_t g_now_us;
typedef uint64_t absolute_time_t;
static inline uint32_t time_us_32() { return (uint32_t)g_now_us; }
static inline absolute_time_t get_absolute_time() { return g_now_us; }
static inline uint32_t to_ms_since_boot(absolute_time_t t) { return (uint32_t)(t / 1000); }
