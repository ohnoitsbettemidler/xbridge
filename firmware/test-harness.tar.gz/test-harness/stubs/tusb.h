#pragma once
extern bool g_mounted;
static inline bool tud_mounted() { return g_mounted; }
